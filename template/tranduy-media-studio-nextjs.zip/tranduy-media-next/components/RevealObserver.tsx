"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";

/** Gắn class .in cho mọi .rv khi cuộn tới; chạy lại mỗi khi đổi trang. */
export default function RevealObserver() {
  const path = usePathname();
  useEffect(() => {
    const els = document.querySelectorAll(".rv:not(.in)");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }),
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [path]);
  return null;
}
