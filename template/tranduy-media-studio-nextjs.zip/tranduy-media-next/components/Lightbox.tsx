"use client";
import { useEffect, useState } from "react";

export type Pic = { img: string; cat: string; alt: string };
const cats = ["Tất cả", "Hậu trường", "Studio", "Sản phẩm", "Chân dung"];

export default function LightboxGallery({ pics }: { pics: Pic[] }) {
  const [cat, setCat] = useState("Tất cả");
  const [cur, setCur] = useState<number | null>(null);
  const list = cat === "Tất cả" ? pics : pics.filter((p) => p.cat === cat);
  useEffect(() => {
    if (cur === null) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setCur(null); if (e.key === "ArrowRight") setCur((c) => (c! + 1) % list.length); if (e.key === "ArrowLeft") setCur((c) => (c! - 1 + list.length) % list.length); };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [cur, list.length]);
  return (
    <>
      <div className="filters">{cats.map((c) => <button key={c} className="chip" aria-pressed={cat === c} onClick={() => { setCat(c); setCur(null); }}>{c}</button>)}</div>
      <div className="gal">{list.map((p, i) => <button key={p.img} onClick={() => setCur(i)} aria-label={p.alt}><img src={`/images/${p.img}.jpg`} alt={p.alt} loading="lazy" /></button>)}</div>
      {cur !== null && (
        <div className="lb" onClick={() => setCur(null)} role="dialog" aria-modal="true">
          <img src={`/images/${list[cur].img}.jpg`} alt={list[cur].alt} onClick={(e) => e.stopPropagation()} />
          <button className="pv" aria-label="Trước" onClick={(e) => { e.stopPropagation(); setCur((cur - 1 + list.length) % list.length); }}>‹</button>
          <button className="nx" aria-label="Sau" onClick={(e) => { e.stopPropagation(); setCur((cur + 1) % list.length); }}>›</button>
          <button className="x" aria-label="Đóng">×</button>
          <div className="cap">{list[cur].cat} · {cur + 1}/{list.length}</div>
        </div>
      )}
    </>
  );
}
