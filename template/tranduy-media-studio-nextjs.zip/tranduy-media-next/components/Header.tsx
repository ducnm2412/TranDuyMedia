"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

export const navLinks = [
  ["/du-an", "Dự án"], ["/dich-vu", "Dịch vụ"], ["/quy-trinh", "Quy trình"], ["/studio", "Studio"],
  ["/thu-vien", "Thư viện"], ["/ve-chung-toi", "Về chúng tôi"], ["/lien-he", "Liên hệ"],
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  return (
    <>
      <header>
        <div className="wrap nav">
          <Link href="/" aria-label="TRAN DUY Media"><img src="/images/logo_w.png" alt="TRAN DUY Media" /></Link>
          <ul>{navLinks.map(([h, l]) => <li key={h}><Link href={h} className={path === h ? "on" : ""}>{l}</Link></li>)}</ul>
          <Link href="/lien-he#datlich" className="cta">Đặt lịch ngay</Link>
          <button className="burger" aria-label="Mở menu" onClick={() => setOpen(true)}><span /></button>
        </div>
      </header>
      <nav className={`menu${open ? " open" : ""}`} aria-label="Menu di động">
        <button className="close" aria-label="Đóng" onClick={() => setOpen(false)}>×</button>
        <Link href="/" onClick={() => setOpen(false)}>Trang chủ</Link>
        {navLinks.map(([h, l]) => <Link key={h} href={h} onClick={() => setOpen(false)}>{l}</Link>)}
        <Link href="/lien-he#datlich" onClick={() => setOpen(false)} style={{ color: "#fff" }}>Đặt lịch</Link>
      </nav>
    </>
  );
}
